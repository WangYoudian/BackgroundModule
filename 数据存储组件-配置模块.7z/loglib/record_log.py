#-*- coding: utf-8 -*-

__author__ = 'F4367281'
__version__ = '1.0'
'''
*********************History**************************
create: 2018/7/7
file name:record_log.py


******************************************************
'''
import os
import time
import json
import platform
import logging
from logging import handlers


class Writelog_V2():
    def __init__(self, logpath=None, logname=None, maxlogSize=1*1024*1024):
        '''
        param:logpath type is string
        param:logname type is string
        '''
        self.logpath = "/var/log/"
        self.logname = "corepro_equipment_system.log"
        self.logmaxSize = maxlogSize
        # if self.logpath == None:
        #     if platform.system() == "Windows":
        #         self.logpath=os.getcwd() #os.path.abspath(os.path.join(os.path.dirname(__file__),os.path.pardir))
        #     else:
        #         self.logpath = "/app/st_mqtt_service/logs" #"/app/st_iot_mqtt_message_service"
        #
        #
        # if self.logname == None:
        #     #self.logname=time.strftime("%Y%m%d",time.localtime())+".log"
        #     self.logname = "st_tem_hum_error.log"

    def savelog(self,logtype="",logbody=""):
        '''
        param:logtype type is string,must
        param:logbody type is string,must
        '''


        try:
            # # logging.basicConfig(filename=os.path.join(self.logpath,self.logname),
            # #                     level=logging.DEBUG,
            # #                     format="%(asctime)s %(name)s %(processName)s %(levelname)s [%(module)s.%(funcName)s] %(message)s ",
            # #                     )
            # # logging.debug("login module test")
            # curTime = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
            # f = open(self.logpath.replace("\\","/")+"/"+self.logname,"a+")
            # f.write(curTime+" "+"["+logtype+"] "+logbody+"\n")
            # f.close()
            # #self.info_msg(msg_body=logbody)

            # =============================================
            logger = logging.getLogger("logger")
            logger.setLevel(logging.DEBUG)

            __fmt = "%(asctime)s %(name)s %(message)s"
            __handler = handlers.RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
                                                     maxBytes=self.logmaxSize,#maxBytes=1*1024*512,
                                                     encoding="utf-8",
                                                     backupCount=1
                                                     )

            __handler.setFormatter(logging.Formatter(__fmt))
            logger.addHandler(__handler)
            logger.debug(msg=logtype+" | "+logbody)
            logger.removeHandler(__handler)
            pass


        except Exception as err:
            #raise Exception(err)
            pass

    def debug_msg(self,msg_body):
        '''
        debug log 信息
        :param msg_body:
        :return:
        '''
        try:
            logger = logging.getLogger("logger")
            logger.setLevel(logging.DEBUG)

            __fmt = "%(asctime)s %(name)s %(message)s"
            __handler = handlers.RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
                                                     maxBytes=self.logmaxSize,#maxBytes=1*1024*512,
                                                     encoding="utf-8",
                                                     backupCount=1
                                                     )
            __handler.setFormatter(logging.Formatter(__fmt))

            # log_file_handler = TimedRotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                             when="M",
            #                                             interval=2,
            #                                             backupCount=2)
            # log_file_handler = RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                        maxBytes=1024*2,
            #                                        encoding="utf-8")

            logger.addHandler(__handler)
            logger.debug(msg=msg_body)
            logger.removeHandler(__handler)

        except Exception as err:
            return None

    def info_msg(self,msg_body):
        '''
        正常信息
        :param msg_body:
        :return:
        '''
        try:
            logger = logging.getLogger("logger")
            logger.setLevel(logging.INFO)

            __fmt = "%(asctime)s [%(levelname)s] %(message)s"
            __handler = handlers.RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
                                                     maxBytes=self.logmaxSize,#maxBytes=1*1024*512,
                                                     encoding="utf-8",
                                                     backupCount=1
                                                     )
            __handler.setFormatter(logging.Formatter(__fmt))

            # log_file_handler = TimedRotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                             when="M",
            #                                             interval=2,
            #                                             backupCount=2)
            # log_file_handler = RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                        maxBytes=1024*2,
            #                                        encoding="utf-8")

            logger.addHandler(__handler)
            logger.info(msg=msg_body)
            logger.removeHandler(__handler)

        except Exception as err:
            print(err)
            return None

    def warning_msg(self,msg_body):
        '''
        警告信息
        :param msg_body:
        :return:
        '''
        try:
            logger = logging.getLogger("logger")
            logger.setLevel(logging.WARNING)

            __fmt = __fmt = "%(asctime)s [%(levelname)s]  %(message)s"
            __handler = handlers.RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
                                                     maxBytes=self.logmaxSize,#maxBytes=1*1024*512,
                                                     encoding="utf-8",
                                                     backupCount=1
                                                     )
            __handler.setFormatter(logging.Formatter(__fmt))

            # log_file_handler = TimedRotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                             when="M",
            #                                             interval=2,
            #                                             backupCount=2)
            # log_file_handler = RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                        maxBytes=1024*2,
            #                                        encoding="utf-8")

            logger.addHandler(__handler)
            logger.warning(msg=msg_body)
            logger.removeHandler(__handler)

        except Exception as err:
            return None

    def error_msg(self,msg_body):
        '''
        錯誤信息
        :param msg_body:
        :return:
        '''
        try:
            logger = logging.getLogger("logger")
            logger.setLevel(logging.ERROR)

            __fmt = "%(asctime)s [%(levelname)s] %(message)s"
            __handler = handlers.RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
                                                     maxBytes=1*1024*512,
                                                     encoding="utf-8",
                                                     backupCount=1
                                                     )
            __handler.setFormatter(logging.Formatter(__fmt))

            # log_file_handler = TimedRotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                             when="M",
            #                                             interval=2,
            #                                             backupCount=2)
            # log_file_handler = RotatingFileHandler(filename=os.path.join(self.logpath,self.logname),
            #                                        maxBytes=1024*2,
            #                                        encoding="utf-8")

            logger.addHandler(__handler)
            logger.error(msg=msg_body)
            logger.removeHandler(__handler)

        except Exception as err:
            return None


