#-*- coding: utf-8 -*-

__author__ = 'F4367281'
__version__ = '1.0'
"""
File Name: writelog
Create Date: 2018/11/26
"""
import os
import traceback
import logging
from logging import handlers
import platform


def singleInstance(cls):
    """
    获取单例装饰器
    :param cls:
    :return:
    """
    instances = {}

    def wrapper(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)

        return instances[cls]

    return wrapper


@singleInstance
class Logger(object):
    def __init__(self, script="",
                 logpath="/var/log",
                 logname="system.log",
                 logmaxsize=1*1024*512,
                 consolelog=True
                 ):
        """

        :param script:
        :param logpath: log 文件路径
        :param logname: log文件名称
        :param logmaxsize: log文件大小
        :param consolelog: 是否在控制台打印log
        """
        self._path = logpath
        self._name = logname
        self._max_size = logmaxsize
        self._stdout = consolelog
        self._level = logging.DEBUG

        self._logger = logging.getLogger()
        self._formater = logging.Formatter("%(asctime)s %(levelname)s %(process)d-%(thread)d [%(pathname)s] [%(filename)s-%(funcName)s] Line: %(lineno)s - %(message)s")

        # 日志路径,不存在则新建
        if os.path.exists(self._path) is False:
            os.makedirs(self._path)

        self._file_name = os.path.join(self._path, self._name)
        # 输出到文件
        self._file_handler = logging.handlers.RotatingFileHandler(filename=self._file_name, encoding="utf-8", maxBytes=self._max_size, backupCount=1)

        # 日志格式
        self._file_handler.setFormatter(self._formater)

        # 日志等级
        self._logger.setLevel(self._level)

        self._logger.addHandler(self._file_handler)

        # 检查当前平台是windows还是linux,windows可以把日志输出到控制台(假定windows为开发环境)
        if platform.system() == "Windows":
            self._stdout = True

        else:
            self._stdout = False

        if self._stdout:
            # 输出到控制台
            self._confole_handler = logging.StreamHandler()
            self._confole_handler.setFormatter(self._formater)
            self._logger.addHandler(self._confole_handler)

    def get_logger(self):
        """

        :return:
        """
        return self._logger

    def info(self, message, *args, optionsmsg=""):
        """
        一般日志
        :param message:
        :return:
        """
        try:
            for msg in args:
                message += " |%s" % (str(msg))

            message += " |%s" % (str(optionsmsg))

            self._logger.info(msg=message)

        except Exception as err:
            print("err", err)
            return False

    def error(self, message, *args, optionsmsg=""):
        """
        错误日志
        :param message:
        :return:
        """
        try:


            for msg in args:
                message += " |%s" % (str(msg))

            message += " |%s" % (str(optionsmsg))

            self._logger.error(msg=message)

        except Exception as err:
            print("err", err)
            return False

    def debug(self, message, *args, optionsmsg=""):
        """
        调试日志
        :param message:
        :return:
        """
        try:
            for msg in args:
                message += " |%s" % (str(msg))

            message += " |%s" % (str(optionsmsg))

            self._logger.debug(msg=message)

        except Exception as err:
            print("err", err)
            return False

    def warring(self, message, *args, optionsmsg=""):
        """
        警告日志
        :param message:
        :return:
        """
        try:

            for msg in args:
                message += " |%s" % (str(msg))

            message += " |%s" % (str(optionsmsg))

            self._logger.warning(msg=message)

        except Exception as err:
            print("err", err)
            return False


logger = Logger().get_logger()

