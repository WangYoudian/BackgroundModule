#-*- coding: utf-8 -*-

__author__ = 'F1336500'
__version__ = '1.0'
'''
*********************History**************************
create: 2020/3/12
file name:__init__.py


******************************************************
'''
import os
import yaml
import traceback
from threading import Lock
from loglib.logger import logger as log
from utilitys.user_dict import ConfigDict

FILE_TYPE = ['.yml', '.json', '.xml']  # 常见配置文件格式


class ReadConfig:
	# 支持多线程的单例模式
	_instance_lock = Lock()

	def __new__(cls, *args, **kargs):
		"""
		https://zhuanlan.zhihu.com/p/60269982
		:param args:
		:param kargs:
		:return:
		"""
		if not hasattr(cls, '_instance'):
			with cls._instance_lock:
				if not hasattr(cls, '_instance'):
					cls._instance = object.__new__(cls)
					# config是实例属性
					cls._instance.config = ConfigDict()

		return cls._instance

	def __init__(self, configuration='env_base.yml'):
		self._config_file = os.path.join(os.path.dirname(__file__), configuration)
		self._logger = log
		self._read()

	# def __enter__(self):
	# 	self._read()
	# 	return self.config

	# def __exit__(self, exc_type, exc_val, exc_tb):
	# 	if exc_val:
	# 		raise exc_val

	def _read(self):
		ext = os.path.splitext(self._config_file)[1]
		if ext == FILE_TYPE[0]:
			self.__read_yaml()
		elif ext == FILE_TYPE[1]:
			self.__read_json()
		elif ext == FILE_TYPE[2]:
			self.__read_xml()
		else:
			raise Exception('Please Check the Configuration File Path')

	def __read_yaml(self):
		if not self.config:
			# self.config['a'] = '1'
			_base_dict = dict()
			with open(self._config_file, encoding='utf-8') as f:
				_base_dict = yaml.load(f, yaml.SafeLoader)

			if _base_dict is None:
				raise Exception('Read YAML Configuration Failed...')

			for key, value in _base_dict.items():
				self.config[key] = value

			_env_type = _base_dict.get('ENV')
			self._logger.info('Current Use Profile: %s', _env_type)

			_env_config = dict()
			try:
				_env_config_file = os.path.join(os.path.dirname(__file__), _env_type + '.yml')
				with open(_env_config_file, encoding='utf-8') as f:
					_env_config = yaml.load(f, yaml.SafeLoader)
			except Exception as err:
				self._logger.error('Read ENV Configuration Failed, %s', err, traceback.format_exc())

			if _env_config is not None:
				for key, value in _env_config.items():
					self.config[key] = value

	def __read_json(self):
		pass

	def __read_xml(self):
		pass

	def get_config(self):
		return self.config

APPLICATION_CONFIG = ReadConfig().get_config()
if not APPLICATION_CONFIG:
	log.error('False Usage of ConfigDict, Which Cause Configuration Loading Failed!')
# print(APPLICATION_CONFIG)
# print(APPLICATION_CONFIG.a)
