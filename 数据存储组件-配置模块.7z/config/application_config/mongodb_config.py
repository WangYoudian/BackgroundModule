#-*- coding: utf-8 -*-

__author__ = 'F4367281'
__version__ = '1.0'
'''
*********************History**************************
create: 2020/2/22
file name:mongodb_config.py


******************************************************
'''

from config.application_config.db_base_config import DbBaseConfig
from config.application_config.constant_default import *
from pymongo.mongo_client import ReadPreference


class MongodbConfig(DbBaseConfig):

    _instance = None

    def __init__(self):
        """

        """
        super(MongodbConfig, self).__init__()
        self.HOST = self.get_property_value(MONGODB_HOST)
        self.PORT = self.get_property_value(MONGODB_PORT)
        self.ADDRESS = self.get_property_value(MONGODB_ADDRESS)

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = object.__new__(cls)

        return cls._instance

    def get_user(self):
        return self.get_property_value(MONGODB_USER)

    def get_password(self):
        return self.get_property_value(MONGODB_PASSWORD)

    def get_auth_db(self):
        return self.get_property_value(MONGODB_AUTH_DB)

    def get_default_db(self):
        return self.get_property_value(MONGODB_DB)

    # def get_node_list(self):
    #     """
    #
    #     :return:
    #     """
    #     host_list = list()
    #     hosts = self.get_address().split(",")
    #     for host in hosts:
    #         host_list.append(host)
    #
    #     return host_list

    def get_max_pool_size(self):
        return self.get_property_value(MONGODB_POOL_MAX_SIZE)

    def get_min_pool_size(self):
        return self.get_property_value(MONGODB_POOL_MIN_SIZE)

    def get_max_idle_time(self):
        return self.get_property_value(MONGODB_POOL_MAX_IDLE_TIME_MS)

    def get_socket_keep_alive(self):
        return self.get_property_value(MONGODB_SOCKET_KEEP_ALIVE_MS)

    def get_heart_beat_frequenctms(self):
        return self.get_property_value(MONGODB_HEAR_BEAT_FREQUENCY_MS)

    def get_connection_setting_value(self):
        """

        :return:
        """
        _config = {
            "maxPoolSize": self.get_max_pool_size(),
            "minPoolSize": self.get_min_pool_size(),
            "maxIdleTimeMS": self.get_max_idle_time(),
            "socketKeepAlive": self.get_socket_keep_alive(),
            "heartbeatFrequencyMS": self.get_heart_beat_frequenctms(),
            # "server_selector": self._server_selector,
            # "read_preference": ReadPreference.SECONDARY
        }

        if self.get_cluster_flag():
            _config["read_preference"] = ReadPreference.SECONDARY
            # _config["server_selector"] = self._server_selector

        return _config

    def _server_selector(self, selections):
        """

        :param selections:
        :return:
        """
        server_list = list()
        for server in selections:
            server_list.append(server)

        return server_list


MONGODB_CONFIG = MongodbConfig()
