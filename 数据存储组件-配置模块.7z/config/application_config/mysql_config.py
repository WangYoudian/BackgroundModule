# -*- coding: utf-8 -*-

__author__ = 'F4367281'
__version__ = '1.0'
'''
*********************History**************************
create: 2020/2/24
file name:mysql_config.py


******************************************************
'''

from .db_base_config import DbBaseConfig
from config.application_config.constant_default import *


class MysqlConfig(DbBaseConfig):

    _instance = None

    def __init__(self):
        """

        """
        super(MysqlConfig, self).__init__()
        self.HOST = self.get_property_value(MYSQL_HOST)
        self.PORT = self.get_property_value(MYSQL_PORT)
        self.ADDRESS = self.get_property_value(MYSQL_ADDRESS)

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = object.__new__(cls)

        return cls._instance

    def get_db(self):
        return self.get_property_value(MYSQL_DB)

    def get_user(self):
        return self.get_property_value(MYSQL_USER)

    def get_password(self):
        return self.get_property_value(MYSQL_PASSWORD)

    def get_min_caches(self):
        return self.get_property_value(MYSQL_MIN_CACHE)

    def get_max_caches(self):
        return self.get_property_value(MYSQL_MAX_CACHE)

    def get_max_connections(self):
        return self.get_property_value(MYSQL_MAX_CONNECTIONS)


MYSQL_CONFIG = MysqlConfig()
