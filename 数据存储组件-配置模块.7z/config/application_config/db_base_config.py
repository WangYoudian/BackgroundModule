#-*- coding: utf-8 -*-

__author__ = 'F4367281'
__version__ = '1.0'
'''
*********************History**************************
create: 2020/2/22
file name:db_config.py


******************************************************
'''
from config import APPLICATION_CONFIG as CONFIG


class DbBaseConfig:

    def __init__(self):
        self.HOST = ""
        self.PORT = 0
        self.ADDRESS = ""

    @staticmethod
    def get_property_value(variable):
        """
        有默认值且与key字符串同名的变量
        :param variable:
        :return: variable默认值或者配置中读取到的值（不为None）
        """
        # variable key not exists, return default value
        if not CONFIG.variable:
            return variable
        # return user dict value
        return CONFIG.variable

    def get_node_list(self):
        """
        根据host解析 node list
        :return:
        """
        return []

    def get_cluster_flag(self):
        """
        如果有多个node list 则返回True,表示当前集群环境
        :return:
        """
        return False if len(self.get_node_list()) == 1 else True

    def get_address(self):
        """

        :return:
        """
        ADDRESS = ""
        return self.get_property_value(ADDRESS)

    def get_host(self):
        """

        :return:
        """
        HOST = ""
        _host = self.get_property_value(HOST)
        if _host == self.HOST:
            _address = self.get_address()
            _address_split = _address.split(",")
            if len(_address_split) == 1:
                _host = _address_split[0].split(":")[0]

        return _host

    def get_port(self):
        """

        :return:
        """
        PORT = ""
        _port = self.get_property_value(PORT)
        if _port == self.PORT:
            _address = self.get_address()
            _address_split = _address.split(",")
            if len(_address_split) == 1:
                _host_port_split = _address_split[0].split(":")
                if len(_host_port_split) == 2:
                    _port = _host_port_split[1]

        return int(_port)
