#-*- coding: utf-8 -*-

__author__ = 'F4367281'
__version__ = '1.0'
'''
*********************History**************************
create: 2020/2/22
file name:redis_config.py


******************************************************
'''
import traceback
from loglib.logger import logger
from config.application_config.db_base_config import DbBaseConfig
from config.application_config.constant_default import *


class RedisConfig(DbBaseConfig):
    """
    redis配置参数
    """
    _instance = None

    def __init__(self):
        """

        """
        super(RedisConfig, self).__init__()
        self.HOST = self.get_property_value(REDIS_HOST)
        self.PORT = self.get_property_value(REDIS_PORT)
        self.ADDRESS = self.get_property_value(REDIS_ADDRESS)

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = object.__new__(cls)

        return cls._instance

    def get_db(self):
        return self.get_property_value(REDIS_DB)

    def get_password(self):
        return self.get_property_value(REDIS_PASSWORD)

    def get_max_connections(self):
        return self.get_property_value(REDIS_MAX_CONNECTIONS)

    # def get_node_list(self):
    #     """
    #     根据`get_host`参数切分成redis 集群连接的startup_nodes类型参数
    #     :return:
    #     """
    #     startup_nodes = list()
    #     try:
    #         hosts = self.get_address().split(",")
    #         for host in hosts:
    #             if host.find(":") != -1:
    #                 host_split = host.split(":")
    #                 startup_nodes.append({"host": host_split[0], "port": host_split[1]})
    #
    #             else:
    #                 startup_nodes.append({"host": host, "port": self.get_port()})
    #
    #     except Exception as err:
    #         logger.error("%s, %s", err, traceback.format_exc())
    #
    #     return startup_nodes
    
    def get_sentinel_node_list(self):
        """
        获取哨兵节点
        :return:
        """
        sentinel_list = list()
        try:
            hosts = self.ADDRESS.split(",")
            for host in hosts:
                if host.find(":") != -1:
                    host_split = host.split(":")
                    sentinel_address = (host_split[0], int(host_split[1]))
                    sentinel_list.append(sentinel_address)

                else:
                    sentinel_address = (host, int(self.get_port()))
                    sentinel_list.append(sentinel_address)

        except Exception as err:
            logger.error("%s, %s", err, traceback.format_exc())

        return sentinel_list


REDIS_CONFIG = RedisConfig()
