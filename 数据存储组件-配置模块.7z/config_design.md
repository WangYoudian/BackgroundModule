### 1.配置格式
`yaml`  
参考链接:[常用配置文件格式](https://colobu.com/2017/08/31/configuration-file-format/)  

### 2.核心设计思路
使用Python读取配置文件过程中，由于配置项种类多而且参数形式各异，使用原始的文件读取库无法满足需求，需要根据文件格式设计ReadConfig类。

### 3.日志输出
使用`loguru`进行优化

### 4.扩展
`json`或`xml`格式文件的读取

