from collections import UserDict


class ConfigDict(UserDict):
    def __getattr__(self, item, default_value=None):
        return self.get(item, default_value)

    def __setitem__(self, key, value):
        self.data[key] = value
