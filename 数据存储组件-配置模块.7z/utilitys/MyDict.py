# 这是自己摸索出来的一种方式，还可以用https://zhuanlan.zhihu.com/p/24305162提供的描述符__get__方法进行转译
# 这里再插入一些描述符的特性：描述符是类属性
# 再插一段关于静态方法的描述：静态方法的作用是——设置环境变量，修改另一个类的变量。在实现时并不需要引用类或者实例。

from collections import UserDict


class AttrDict(UserDict):
    def __getattr__(self, attr):
        return self[attr]

    def __setitem__(self, key, value):
        """
        AttrDict([('name', 'wincer')]) 设置name属性值为wincer
        """
        self.data[key] = value


c = AttrDict([('name', 'wincer')])
# c = AttrDict()
c.a = 1
c['b'] = 2

print(c.a)
print(c)  # data部分
print(c.__dict__)
print(c.data)
print(c.b)
print(c.get('c', 'null'))

# deploy
copy = c
print(copy.a)


# 当
