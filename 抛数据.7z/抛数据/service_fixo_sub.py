#-*- coding: utf-8 -*-

__author__ = 'FIIBEACON CorePro Team'
__version__ = '1.0'
'''
*********************History**************************
create: 2018/12/5
file name:properties_pub.py
******************************************************
'''

from utils.oauth_login import oauth_check
from paho.mqtt.client import Client
import time,json
import random


class Publishdata:
    def __init__(self, host, port, user, password, topic, client_id):
        print("dsafdsafadsfadafdasf",host,port,user,password)
        self.__mqttClient = Client(client_id=client_id)
        self.__host = host
        self.__port = port
        self.__user = user
        # self.__user = "corePro"
        self.__password = password
        # self.__password = "foxconn168!"
        self.__mqtt_flag = False
        self.topic = topic

    def __OnConnect(self, client, userdata, flags, rc):
        """

        :param client:
        :param userdata:
        :param flags:
        :param rc:
        :return:
        """
        try:
            self.__mqtt_flag = True
            print("created connection ... ", rc)
            # topic = self.topic+'/reply'
            topic = '%s/reply' % self.topic
            # print(topic)
            client.subscribe(topic=topic)
        except Exception as err:
            pass

    def __OnDisconnect(self, client, userdata, rc):
        """
        断开连接处理
        :param client:
        :param userdata:
        :param rc:
        :return:
        """
        self.__mqtt_flag = False
        print("connection loss .... ", rc)

    def __OnMessage(self, client, userdata, message):
        """
        消息处理
        :param client:
        :param userdata:
        :param message:
        :return:
        """
        print("[ON MESSAGE %s]" % message.topic,message.payload)

    def connectBroker(self, topic, data, timecycle):
        try:
            self.__mqttClient.on_connect = self.__OnConnect
            self.__mqttClient.on_disconnect = self.__OnDisconnect
            self.__mqttClient.on_message = self.__OnMessage
            self.__mqttClient.username_pw_set(username=self.__user, password=self.__password)
            # self.__mqttClient.username_pw_set(username="corePro", password="foxconn168!")
            self.__mqttClient.connect_async(host=self.__host, port=self.__port)

            self.__mqttClient.loop_start()
            # self.__mqttClient.loop_forever()
            a = 0
            while True:
                if self.__mqtt_flag is False:
                    if a == 5:
                        print("MQTT connection lose,will retry connect...")
                        try:
                            self.__mqttClient.connect_async(host=self.__host,
                                                            port=self.__port
                                                            )
                            self.__mqttClient.loop_start()
                        except Exception as err:
                            pass
                        a = 0
                    a += 1


                self.push(topic=topic,
                          data=service_data)
                # sleeptime = random.randint(1, 6)

                time.sleep(2)

        except Exception as err:
            print(err, 111111111111)

    def push(self, topic, data):
        """
        推数据
        :param topic:
        :param data:
        :return:
        """
        # print(data,1111111111)
        if self.__mqttClient is not None:
            res = self.__mqttClient.publish(topic=topic,
                                            payload=json.dumps(data, ensure_ascii=False),
                                            qos=1,
                                            retain=False
                                            )
            # ******************
            # 这里打印返回值
            # ******************
            print(res)
            print(topic,data)
            # print(datetime.now())n

            # except Exception as err:
            #     print(err)


if __name__ == "__main__":
    #填写设备三元组信息
    PRODUCT_ID = '6647535040164243775'
    DEVICE_NAME = 'mo1'
    DEVICE_SECRET = 'fc139eb25afb00c774b6bc88b6840712f2127b035072a8a9e19461142f285717'

    # Fixo HA Address for activemq
    # OAUTH_CHECK_URL = "http://api.10.134.170.152.xip.io/corepro/auth/mqtt/"
    OAUTH_CHECK_URL = "http://api.std.corepro.10.124.130.142.xip.io/corepro/auth/mqtt"

    iotuser, iottoken, iotId, iotHost, iotPort = oauth_check().verfiy(PRODUCT_ID, DEVICE_NAME,DEVICE_SECRET,OAUTH_CHECK_URL)
    iotHost = '10.124.130.118'
    iotPort = 80
    # iotuser = iottoken = False
    if iotuser and iottoken:
        print("设备凭证信息：", iotuser, iottoken)
        topic = "/6647535040164243775/mo1/service/quality_safety/reply"



        #数据发送周期定义
        # timecycle ="数据发送周期定义"
        # 示例：
        timecycle = 1

        # deviceinfo_data ={
        #     'id': int(time.time()),
        #     'params': {
        #         'status': 1,
        #         "cpu":10.0,
        #         "disk":10.0,
        #         "memory":20.0,
        #         "ip":"",
        #         "operatingSystem":"Ubuntu",
        #         "timestamp":"",
        #         "instructionSchema":"ARM-A8"
        #     }
        # }

        # property_data ={
        #     "msg_ver": 100,
        #     "id": int(time.time()),
        #     "params": {
        #         "property01": 10,
        #         "property02": "string",
        #     },
        #     "reply":True
        # }


        # event_data = {
        #     "id": int(time.time()),
        #     "params": {"value":
        #         {
        #             "event01_01_outpur": 123.456,
        #             "event01_output": 100,
        #         },
        #         "reply":True
        #     }
        # }

        service_data = {
            "id": int(time.time()),
            "params": {
                "is_qualitfied": 100
            }
        }

        # Publishdata("10.134.170.210", 1883, iotuser, iottoken,topic,iotId).connectBroker(topic,service_data,timecycle)
        Publishdata(iotHost, iotPort, iotuser, iottoken,topic,iotId).connectBroker(topic,service_data,timecycle)

    else:
        print('连接鉴权失败，请检查鉴权信息是否正常！！！！')