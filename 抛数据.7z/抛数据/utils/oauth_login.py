#-*- coding: utf-8 -*-

__author__ = 'FIIBEACON CorePro Team'
__version__ = '1.0'
'''
*********************History**************************
create: 2018/12/5
file name:oauth_login.py
******************************************************
'''

import requests, time,traceback
from utils.sha256lib import Sha256Lib


class oauth_check():
    """
    验证设备连接三元组
    """

    def verfiy(self, product_key, device_name, SECRET_KEY,OAUTH_CHECK_URL,method="HmacSHA256"):
        """

        :param product_key:
        :param device_name:
        :param method:
        :return:
        """
        iotuser = ""
        iottoken = ""
        iotId = ""
        iotHost = ""
        iotPort = ""
        try:
            auth = {
                "timestamp": int(time.time()),
                "productKey": product_key,
                "deviceName": device_name
            }
            print(Sha256Lib().sortedDict(auth))
            auth["sign"] = Sha256Lib().convertToSha256(SECRET_KEY,
                                                       Sha256Lib().sortedDict(auth)
                                                       )
            auth["signmethod"] = method

            print(auth,11111111)
            res = requests.post(OAUTH_CHECK_URL, data=auth)
            print(res.status_code)
            resObj = res.json()
            print(resObj)
            if resObj["status"] == '0':
                iotuser = resObj["payload"][0]["iotId"]
                iottoken = resObj["payload"][0]["iotToken"]
                iotId = resObj["payload"][0]["iotId"]
                iotHost = resObj["payload"][0]["iotHost"]
                iotPort = resObj["payload"][0]["iotPort"]
        except Exception as err:
            traceback.print_exc()
        finally:
            return iotuser, iottoken,iotId,iotHost,iotPort


