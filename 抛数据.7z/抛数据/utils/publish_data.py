#-*- coding: utf-8 -*-

__author__ = 'FIIBEACON CorePro Team'
__version__ = '1.0'
'''
*********************History**************************
create: 2018/12/5
file name:publish_data.py
******************************************************
'''

import  time, json
from paho.mqtt.client import Client
from datetime import datetime


class Publishdata:

    def __init__(self, host, port, user, password,topic,client_id):
        self.__mqttClient = Client(client_id=client_id)
        self.__host = host
        self.__port = port
        self.__user = user
        self.__password = password
        self.__mqtt_flag = False
        self.topic = topic


    def __OnConnect(self, client, userdata, flags, rc):
        """

        :param client:
        :param userdata:
        :param flags:
        :param rc:
        :return:
        """
        try:
            self.__mqtt_flag = True
            print("created connection ... ", rc)
            # topic = self.topic+'/reply'
            topic = '%s/reply'%self.topic
            print(topic)
            client.subscribe(topic=topic)
        except Exception as err:
            pass

    def __OnDisconnect(self, client, userdata, rc):
        """
        断开连接处理
        :param client:
        :param userdata:
        :param rc:
        :return:
        """
        self.__mqtt_flag = False
        print("connection loss .... ", rc)

    def __OnMessage(self, client, userdata, message):
        """
        消息处理
        :param client:
        :param userdata:
        :param message:
        :return:
        """
        print(message.topic+':')
        print(message.payload)
        print("on message...........................")
        # print(eval(message.payload)['_device_name'])
        pass

    def connectBroker(self,topic,data,timecycle):
        try:
            self.__mqttClient.on_connect = self.__OnConnect
            self.__mqttClient.on_disconnect = self.__OnDisconnect
            self.__mqttClient.on_message = self.__OnMessage
            # self.__mqttClient.username_pw_set(username=self.__user, password=self.__password)
            self.__mqttClient.username_pw_set(username="corePro", password="foxconn168!")
            self.__mqttClient.connect_async(host=self.__host,port=self.__port)

            self.__mqttClient.loop_start()
            # self.__mqttClient.loop_forever()
            a = 0
            while True:
                if self.__mqtt_flag is False:
                    if a == 5:
                        print("MQTT connection lose,will retry connect...")
                        try:
                            self.__mqttClient.connect_async(host=self.__host,
                                                            port=self.__port
                                                            )
                            self.__mqttClient.loop_start()
                        except Exception as err:
                            pass
                        a = 0
                    a += 1

                self.push(topic=topic,
                          data=data)

                time.sleep(0.001)

        except Exception as err:
            print(err,111111111111)

    def push(self, topic, data):
        """
        推数据
        :param topic:
        :param data:
        :return:
        """
        # print(data,1111111111)
        if self.__mqttClient is not None:
            res = self.__mqttClient.publish(topic=topic,
                                            payload=json.dumps(data, ensure_ascii=False),
                                            qos=1,
                                            retain=False
                                            )
        
            print(res)
            # print(topic,data)
            # print(datetime.now())

        # except Exception as err:
        #     print(err)

