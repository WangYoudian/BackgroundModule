#-*- coding: utf-8 -*-

__author__ = 'FIIBEACON CorePro Team'
__version__ = '1.0'
'''
*********************History**************************
create: 2018/12/5
file name:sha256lib.py
******************************************************
'''

import hmac
import hashlib


class Sha256Lib:
    """
    sha256编码
    """

    def sortedDict(self, data):
        """
        json的key按照a-z顺序排序,并返回key+value字符串
        :param adict:
        :return:
        """
        tmpStr = ""
        dict = sorted(data.items(), key=lambda d:d[0])
        for item in dict:
            if item[0] != "sign" and item[0] != "signmethod": # sign 和 signmethod 不参与排序及sha256编码
                tmpStr += "%s%s" % (item[0], str(item[1]))
        return tmpStr

    def convertToSha256(self, key, value):
        """
        sha256编码
        :param key: 安全密匙
        :param value: 需要进行sha256编码的字符串
        :return:
        """
        secret_key = bytearray.fromhex(key)
        signa = hmac.new(secret_key, value.encode("utf-8"), hashlib.sha256)
        return signa.hexdigest()

